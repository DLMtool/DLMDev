# This file is automatically built by DataObjectsforDLMtool.r in DLMDev
# Don't edit by hand!
# 

#'  Albacore Stock
#'
#'  An object of class Stock
#'
"Albacore"


#'  Blue_shark Stock
#'
#'  An object of class Stock
#'
"Blue_shark"


#'  Bluefin_tuna Stock
#'
#'  An object of class Stock
#'
"Bluefin_tuna"


#'  Bluefin_tuna_WAtl Stock
#'
#'  An object of class Stock
#'
"Bluefin_tuna_WAtl"


#'  Butterfish Stock
#'
#'  An object of class Stock
#'
"Butterfish"


#'  Herring Stock
#'
#'  An object of class Stock
#'
"Herring"


#'  Mackerel Stock
#'
#'  An object of class Stock
#'
"Mackerel"


#'  Porgy Stock
#'
#'  An object of class Stock
#'
"Porgy"


#'  Rockfish Stock
#'
#'  An object of class Stock
#'
"Rockfish"


#'  Snapper Stock
#'
#'  An object of class Stock
#'
"Snapper"


#'  Sole Stock
#'
#'  An object of class Stock
#'
"Sole"


#'  Toothfish Stock
#'
#'  An object of class Stock
#'
"Toothfish"


#'  DecE_Dom Fleet
#'
#'  An object of class Fleet
#'
"DecE_Dom"


#'  DecE_HDom Fleet
#'
#'  An object of class Fleet
#'
"DecE_HDom"


#'  DecE_NDom Fleet
#'
#'  An object of class Fleet
#'
"DecE_NDom"


#'  FlatE_Dom Fleet
#'
#'  An object of class Fleet
#'
"FlatE_Dom"


#'  FlatE_HDom Fleet
#'
#'  An object of class Fleet
#'
"FlatE_HDom"


#'  FlatE_NDom Fleet
#'
#'  An object of class Fleet
#'
"FlatE_NDom"


#'  Generic_DecE Fleet
#'
#'  An object of class Fleet
#'
"Generic_DecE"


#'  Generic_FlatE Fleet
#'
#'  An object of class Fleet
#'
"Generic_FlatE"


#'  Generic_Fleet Fleet
#'
#'  An object of class Fleet
#'
"Generic_Fleet"


#'  Generic_IncE Fleet
#'
#'  An object of class Fleet
#'
"Generic_IncE"


#'  IncE_HDom Fleet
#'
#'  An object of class Fleet
#'
"IncE_HDom"


#'  IncE_NDom Fleet
#'
#'  An object of class Fleet
#'
"IncE_NDom"


#'  Low_Effort_Non_Target Fleet
#'
#'  An object of class Fleet
#'
"Low_Effort_Non_Target"


#'  Target_All_Fish Fleet
#'
#'  An object of class Fleet
#'
"Target_All_Fish"


#'  Targeting_Small_Fish Fleet
#'
#'  An object of class Fleet
#'
"Targeting_Small_Fish"


#'  Generic_Obs Obs
#'
#'  An object of class Obs
#'
"Generic_Obs"


#'  Imprecise_Biased Obs
#'
#'  An object of class Obs
#'
"Imprecise_Biased"


#'  Imprecise_Unbiased Obs
#'
#'  An object of class Obs
#'
"Imprecise_Unbiased"


#'  Perfect_Info Obs
#'
#'  An object of class Obs
#'
"Perfect_Info"


#'  Precise_Biased Obs
#'
#'  An object of class Obs
#'
"Precise_Biased"


#'  Precise_Unbiased Obs
#'
#'  An object of class Obs
#'
"Precise_Unbiased"


#'  Overages Imp
#'
#'  An object of class Imp
#'
"Overages"


#'  Perfect_Imp Imp
#'
#'  An object of class Imp
#'
"Perfect_Imp"


#'  Feasibility Fease
#'
#'  An object of class Fease
#'
"Feasibility"


#'  Feasibility2 Fease
#'
#'  An object of class Fease
#'
"Feasibility2"


#'  Atlantic_mackerel Data
#'
#'  An object of class Data
#'
"Atlantic_mackerel"


#'  China_rockfish Data
#'
#'  An object of class Data
#'
"China_rockfish"


#'  Cobia Data
#'
#'  An object of class Data
#'
"Cobia"


#'  Example_datafile Data
#'
#'  An object of class Data
#'
"Example_datafile"


#'  Gulf_blue_tilefish Data
#'
#'  An object of class Data
#'
"Gulf_blue_tilefish"


#'  ourReefFish Data
#'
#'  An object of class Data
#'
"ourReefFish"


#'  Red_snapper Data
#'
#'  An object of class Data
#'
"Red_snapper"


#'  Simulation_1 Data
#'
#'  An object of class Data
#'
"Simulation_1"


#'  testOM OM
#'
#'  An object of class OM
#'
"testOM"


#'  StockDescription 
#'
#'  A data.frame with description of slots for class Stock
#'
"StockDescription"


#'  FleetDescription 
#'
#'  A data.frame with description of slots for class Fleet
#'
"FleetDescription"


#'  ObsDescription 
#'
#'  A data.frame with description of slots for class Obs
#'
"ObsDescription"


#'  ImpDescription 
#'
#'  A data.frame with description of slots for class Imp
#'
"ImpDescription"


#'  DataDescription 
#'
#'  A data.frame with description of slots for class Data
#'
"DataDescription"


#'  OMDescription 
#'
#'  A data.frame with description of slots for class OM
#'
"OMDescription"


