library(testthat)
library(DLMtool)

test_check("DLMtool")
